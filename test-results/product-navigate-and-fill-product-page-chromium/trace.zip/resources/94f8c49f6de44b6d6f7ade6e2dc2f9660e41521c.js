/**
 * Custom Errors By Ingo Philipp
 */
$.extend($.idealforms.errors, {
  pastdate:		'Must be today or somewhere in the past',
  dateinterval:	'You must be between 18 and 70 years of age',
  futuredate: 'Must be more than one month in the future'
});